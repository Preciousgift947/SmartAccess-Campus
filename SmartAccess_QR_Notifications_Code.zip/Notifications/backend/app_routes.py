# Add these routes to the team's existing Flask app.py.
from flask import request, jsonify
from .notifications import (
    create_notification, get_student_notifications,
    mark_notification_read
)

@app.get("/api/notifications/<int:student_id>")
def api_get_notifications(student_id):
    connection = get_db_connection()
    try:
        return jsonify(get_student_notifications(connection, student_id))
    finally:
        connection.close()

@app.post("/api/notifications")
def api_create_notification():
    data = request.get_json(silent=True) or {}
    required = ["student_id", "title", "message"]
    if any(not data.get(x) for x in required):
        return jsonify({"error": "student_id, title and message are required"}), 400

    connection = get_db_connection()
    try:
        notification_id = create_notification(
            connection, data["student_id"], data["title"],
            data["message"], data.get("notification_type", "general")
        )
        return jsonify({"success": True, "notification_id": notification_id}), 201
    finally:
        connection.close()

@app.put("/api/notifications/<int:notification_id>/read")
def api_mark_notification_read(notification_id):
    data = request.get_json(silent=True) or {}
    student_id = data.get("student_id")
    if not student_id:
        return jsonify({"error": "student_id is required"}), 400

    connection = get_db_connection()
    try:
        return jsonify({
            "success": mark_notification_read(
                connection, notification_id, student_id
            )
        })
    finally:
        connection.close()

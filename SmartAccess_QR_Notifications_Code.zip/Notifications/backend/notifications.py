# NOTIFICATION SYSTEM
from datetime import datetime, timezone

def create_notification(connection, student_id, title, message, notification_type="general"):
    cursor = connection.cursor()
    cursor.execute("""
        INSERT INTO notifications
        (student_id, title, message, notification_type, is_read, created_at)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (student_id, title, message, notification_type, False,
          datetime.now(timezone.utc)))
    connection.commit()
    return cursor.lastrowid

def get_student_notifications(connection, student_id):
    cursor = connection.cursor(dictionary=True)
    cursor.execute("""
        SELECT id, title, message, notification_type, is_read, created_at
        FROM notifications
        WHERE student_id = %s
        ORDER BY created_at DESC
    """, (student_id,))
    return cursor.fetchall()

def mark_notification_read(connection, notification_id, student_id):
    cursor = connection.cursor()
    cursor.execute("""
        UPDATE notifications SET is_read = TRUE
        WHERE id = %s AND student_id = %s
    """, (notification_id, student_id))
    connection.commit()
    return cursor.rowcount > 0

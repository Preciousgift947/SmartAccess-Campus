// NOTIFICATION SYSTEM FRONTEND
async function loadNotifications(studentId) {
    const response = await fetch(`/api/notifications/${studentId}`);
    const notifications = await response.json();
    renderNotifications(notifications);
}

function renderNotifications(notifications) {
    const container = document.getElementById("notifications");
    if (!container) return;

    container.innerHTML = "";
    notifications.forEach(n => {
        const item = document.createElement("article");
        item.className = n.is_read ? "notification read" : "notification unread";
        item.innerHTML = `
            <h3>${escapeHtml(n.title)}</h3>
            <p>${escapeHtml(n.message)}</p>
            <small>${escapeHtml(n.notification_type)}</small>
        `;
        container.appendChild(item);
    });
}

function escapeHtml(value) {
    const div = document.createElement("div");
    div.textContent = value ?? "";
    return div.innerHTML;
}

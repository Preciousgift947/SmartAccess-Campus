// QR VERIFICATION FRONTEND
async function verifyQRCode(token) {
    if (!token) {
        showVerificationResult(false, "Please scan a QR code.");
        return;
    }

    try {
        const response = await fetch("/api/qr/verify", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({token})
        });

        const result = await response.json();
        showVerificationResult(result.verified, result.message, result.student);
    } catch (error) {
        console.error(error);
        showVerificationResult(false, "Verification server unavailable.");
    }
}

function showVerificationResult(verified, message, student = null) {
    const box = document.getElementById("verification-result");
    if (!box) return;

    box.textContent = student ? `${message}: ${student.name}` : message;
    box.dataset.status = verified ? "approved" : "denied";
}

# Add these routes to the team's existing Flask app.py.
from flask import request, jsonify
from .qr_module import verify_qr_token

@app.post("/api/qr/verify")
def api_verify_qr():
    data = request.get_json(silent=True) or {}
    connection = get_db_connection()
    try:
        result = verify_qr_token(connection, data.get("token"))
        return jsonify(result), 200 if result["verified"] else 403
    finally:
        connection.close()

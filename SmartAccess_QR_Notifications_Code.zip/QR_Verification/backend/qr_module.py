# QR VERIFICATION MODULE
import secrets
import qrcode

def generate_qr_token():
    return secrets.token_urlsafe(32)

def generate_qr_image(token, output_path):
    image = qrcode.make(token)
    image.save(output_path)
    return output_path

def verify_qr_token(connection, token):
    if not token:
        return {"verified": False, "message": "QR token is required"}

    cursor = connection.cursor(dictionary=True)
    cursor.execute("""
        SELECT student_id, student_number, name, status
        FROM students WHERE qr_token = %s LIMIT 1
    """, (token,))
    student = cursor.fetchone()

    if not student:
        return {"verified": False, "message": "Invalid QR code"}

    if str(student["status"]).lower() != "active":
        return {"verified": False, "message": "Student account is inactive"}

    return {
        "verified": True,
        "message": "Access verified",
        "student": {
            "student_id": student["student_id"],
            "student_number": student["student_number"],
            "name": student["name"]
        }
    }

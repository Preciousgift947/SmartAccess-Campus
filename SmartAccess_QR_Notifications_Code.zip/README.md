# SmartAccess Campus — QR Verification & Notifications

## QR Verification
- `QR_Verification/backend/qr_module.py` — Python QR token generation and verification
- `QR_Verification/backend/app_routes.py` — Flask verification API
- `QR_Verification/frontend/js/qr-verification.js` — JavaScript frontend integration

## Notifications
- `Notifications/backend/notifications.py` — Python notification functions
- `Notifications/backend/app_routes.py` — Flask notification API
- `Notifications/frontend/js/notifications.js` — JavaScript notification display

## Database
- `database/schema.sql` — MySQL tables for students, QR verification logs and notifications

## Integration
Copy the route code into the team's existing Flask `app.py` and connect it to the team's existing `get_db_connection()` function.

The notification module provides the core notification functionality. Firebase Cloud Messaging or Browser Push API can be added later for real-time browser push notifications.
